<?php

xhprof_enable();
echo "PREPENDED\n";
